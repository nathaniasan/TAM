package com.example.styletheme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    ImageButton btn_1, btn_2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_1 = (ImageButton) findViewById(R.id.btn_wal1);
        btn_2 = (ImageButton) findViewById(R.id.btn_wal2);

        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ThemeActivity.class);
                String pathpic = "btn_1";
                i.putExtra("PATH_PICTURE", pathpic);
                startActivity(i);
            }
        });

        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ThemeActivity.class);
                String pathpic = "btn_2";
                i.putExtra("PATH_PICTURE", pathpic);
                startActivity(i);
            }
        });
    }
}