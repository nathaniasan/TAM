package com.example.loginfragment;

public interface CallbackFragment {
    void changeFragment();
}
