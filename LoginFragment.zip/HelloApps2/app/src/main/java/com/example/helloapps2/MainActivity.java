package com.example.helloapps2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void GoToActivity2(View view){

        EditText nama = findViewById(R.id.nama1);
        String aInput = nama.getText().toString();

        EditText npm = findViewById(R.id.npm1);
        String npmInput = npm.getText().toString();

        EditText jkl = findViewById(R.id.jk1);
        String jkInput = jkl.getText().toString();

        EditText alamat = findViewById(R.id.alamat1);
        String alamatInput = alamat.getText().toString();

        EditText pekerjaan = findViewById(R.id.pkrj1);
        String pkrjInput = pekerjaan.getText().toString();

        Intent gotoActivity2 = new Intent(this,MainActivity2.class);

        gotoActivity2.putExtra("tampilnama",aInput);
        gotoActivity2.putExtra("tampilnpm",npmInput);
        gotoActivity2.putExtra("txtjkl",jkInput);
        gotoActivity2.putExtra("txtalamat",alamatInput);
        gotoActivity2.putExtra("txtpkrj",pkrjInput);

        startActivity(gotoActivity2);
    }
}

