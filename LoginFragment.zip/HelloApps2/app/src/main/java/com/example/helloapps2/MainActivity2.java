package com.example.helloapps2;

import static com.example.helloapps2.R.id.button1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String nama = getIntent().getStringExtra("aInput");
        String npm = getIntent().getStringExtra("npmInput");
        String jkl = getIntent().getStringExtra("jkInput");
        String alamat = getIntent().getStringExtra("alamatInput");
        String pekerjaan = getIntent().getStringExtra("pkrjInput");

        TextView tampilnama = findViewById(R.id.tampilnama);
        TextView tampilnpm = findViewById(R.id.tampilnpm);
        TextView txtjkl = findViewById(R.id.tampiljk);
        TextView txtalamat = findViewById(R.id.tampilalamat);
        TextView txtpkrj = findViewById(R.id.tampilpekerjaan);

        tampilnama.setText(nama);
        tampilnpm.setText(npm);
        txtjkl.setText(jkl);
        txtalamat.setText(alamat);
        txtpkrj.setText(pekerjaan);

    };
}