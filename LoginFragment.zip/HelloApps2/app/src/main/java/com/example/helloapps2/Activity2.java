package com.example.helloapps2;

public class Activity2 {
}
